const readline = require('readline-sync');

const num = parseInt(readline.question("Digite um numero: "));

let inicio = 1;    
let soma = 0;   

while (inicio <= num) {
    soma += inicio;
    inicio ++;    
}

console.log(`A soma dos primeiros ${num} números naturais é: ${soma}`);
