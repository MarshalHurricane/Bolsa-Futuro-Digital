const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Qual seu nome: ", (nome) => {
rl.question("Informe seu salário: ", string => {
    const salario = parseFloat(string);

    const reajuste = salario * 0.03
    const abono = 200
    let retorno

    if (salario <= 1050) {
      retorno = reajuste + abono + salario
    } else {
      retorno = reajuste + salario
    }

    console.log(`Informo ao funcionário(a) ${nome} que seu salário teve o valor atualizado para R$ ${retorno}`);

    rl.close();
  });
});

