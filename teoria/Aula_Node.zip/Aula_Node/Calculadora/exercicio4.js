const readline = require('readline-sync');

console.log("-----------------------------------------------");
console.log("Calculadora online");
console.log("-----------------------------------------------");

while(true){
console.log("Bem vindo a Calculadora online!")
operacao = ["soma", "Subtracao", "Multiplicacao", "divisao"]
opcao = readline.keyInSelect(operacao, "Qual calculo deseja realizar: " )

 if (opcao === -1) {
        console.log("Operação finalizada!");
        break;
 }
let x = readline.questionFloat("Digite o primeiro numero: ")
let y = readline.questionFloat("Digite o segundo numero: ")

let resultado

switch (opcao) {
        case 0:
            resultado = x + y;
            console.log(`resultado =${resultado}`);
            break;
        case 1:
            resultado = x - y;
            console.log(`resultado =${resultado}`);
            break;
        case 2:
            resultado = x * y;
            console.log(`resultado =${resultado}`);
            break;
        case 3:
            resultado = x / y;
            console.log(`resultado =${resultado}`);
            break;
        default:
            console.log("Opcao invalida!");
            continue;
    }
}

/* uso do while com true e break, podemos usar o -1 como parametro tambem mas com a 
variavel opcao fora do while, e podemos fazer a calculadora sem while somente com as 
opcões, e podemos usar a opção dada pelo metodo keyInSelect -1 dentro do case
*/