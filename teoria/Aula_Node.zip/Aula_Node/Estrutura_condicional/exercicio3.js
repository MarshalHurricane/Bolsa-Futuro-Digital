const readline  = require('readline-sync') 

console.log("Para consultar a disponibilidade de auxílio, insira os dados abaixo:")
let nome = readline.question("Informe seu nome: ")
let idade = readline.question("Informe sua idade: ")
let salario = readline.questionFloat("Informe seu atual salario: ")
let auxilio

if(salario <= 3000){
    auxilio = 100
    if(salario <= 1000 && idade > 18){
        auxilio = 1000
    }
    else if(salario <= 1000){
        auxilio = 700
    }
    else if(salario <= 2000){
        auxilio = 500
    }
}
else{
    auxilio = "Você não tem direito a auxilio"
}

console.log(`Sr(a) ${nome} seu auxilio é de R$${auxilio}`)
