const readline  = require('readline-sync') 

let valor_total

console.log("-----------------------------------------------");
console.log("Sistema de pagamentos");
console.log("-----------------------------------------------");


const valor_Produto = readline.questionFloat("Informe o valor do produto: ")
console.log("Formas de pagamento: \n1-Dinheiro ou pix \n 2-Cartão de crédito")
const Forma_Pagamento = readline.questionInt("Digite o codigo da forma de pagamento: ")

if(Forma_Pagamento == 1){
    valor_total = valor_Produto - (valor_Produto * 0.15)
    console.log(`Ficou o total de R$ ${valor_total}`)
}
else if (Forma_Pagamento == 2){
    console.log("1-Á vista \n2-Prcelado") 
    const Credito = readline.questionInt("Digite a opcao: ")
    if(Credito == 1){
        valor_total = valor_Produto - (valor_Produto * 0.10)
        console.log(`Ficou o total de R$${valor_total}`)
    }
    else if(Credito == 2){
        const parcelamento = readline.questionInt("Em Quantas vezes ?")
        if (parcelamento == 2){
            console.log(`Ficou o total de R$ ${valor_Produto}, ficando ${valor_Produto/parcelamento} em ${parcelamento} x sem juros`)
        }
        else{
            valor_total = valor_Produto + (valor_Produto * 0.10 )
            console.log(`Ficou o total de R$ ${valor_total}, ficando ${valor_total / parcelamento} em ${parcelamento} `) 
        }
    }
}
else{
    console.log("opcao invalida")
}