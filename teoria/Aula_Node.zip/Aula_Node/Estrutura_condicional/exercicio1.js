const rl  = require('readline-sync') 

let salario = rl.questionFloat("Informe seu salario atual: ")
let reajuste = salario + (salario * 0.03)
let abono = 200
let salario_atual

if(salario <= 1050){
    salario_atual = salario + reajuste + abono
}
else{
    salario_atual = salario + reajuste
}

console.log("Seu salario foi atualizado para R$" + salario_atual.toFixed(2))

//é um método que retorna uma string, do qual um número com um número específico de casas decimais, usado somente para retorno
//alguns alunos usaram e por isso botei a explicação, é so para deixar a saida de resultado "bonita", exemplo de saida: "R$1935.65" para a entrada 885